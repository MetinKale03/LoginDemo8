package com.example.logindemo;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

public class InfoFragment extends Fragment {
    TextView Name;
    TextView Password;
    TextView Loon;
    private WorkViewmodel viewmodel;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_info,container, false);
        viewmodel= ViewModelProviders.of(requireActivity()).get(WorkViewmodel.class);
        Name=view.findViewById(R.id.txtName);
        Password=view.findViewById(R.id.txtPassword);
        Loon=view.findViewById(R.id.txtLoon);
        if(viewmodel.getLoon().getValue()!=null){
            Loon.setText(viewmodel.getLoon().getValue().toString());
        }
        TextWatcher loonWatcher=new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(!editable.toString().equals("")){
                    viewmodel.getLoon().setValue(Double.valueOf(editable.toString()));
                }

            }
        };
        Loon.addTextChangedListener(loonWatcher);

        final Observer<String> userNameObserver= new Observer<String>() {
            @Override
            public void onChanged(String userName) {
                Name.setText(userName);
            }
        };
        viewmodel.getUserName().observe(requireActivity(),userNameObserver);
        final Observer<String> userPasswordObserver= new Observer<String>() {
            @Override
            public void onChanged(String userPassword) {
                Password.setText(userPassword.replaceAll(".","*"));
            }
        };
        viewmodel.getUserPassword().observe(requireActivity(),userPasswordObserver);
        return view;
    }
}
